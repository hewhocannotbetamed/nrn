class RxDException(Exception):
    pass
    
