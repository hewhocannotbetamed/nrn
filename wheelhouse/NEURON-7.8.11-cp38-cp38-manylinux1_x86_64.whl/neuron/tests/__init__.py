from neuron.tests import test_all, test_rxd

suite = test_all.suite

