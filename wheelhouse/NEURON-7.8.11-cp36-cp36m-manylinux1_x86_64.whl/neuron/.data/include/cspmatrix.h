#define cmplx_spPrefix
#include "spmatrix.h"
